To run the Moquette distribution, untar the archive and run the script bin/moquette.sh
Moquette runs with JDK 8, tested with Oracle Java 8
